export = {
  "root": {
    "basic-calculator" : {
    		"sampleString": "The strings file can be used to manage translatable resources"
    }
  }
};